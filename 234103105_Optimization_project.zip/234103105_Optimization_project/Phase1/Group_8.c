#include <stdio.h>
#include <stdlib.h>
#include<math.h>
double bounding_phase(double a, double b, double limits[]);
double newton_raphson(double xprev, double x);

int main()
{   double a,b; //Range of x
    printf("Enter a - lower limit of x");
    scanf("%lf", &a);
    printf("Enter b - upper limit of x");
    scanf("%lf", &b);
    double limits[2]; // Creating an array which can store the values returned by bounding_phase
    bounding_phase(a,b,limits);
    double l1,l2;
    l1=limits[0];
    l2=limits[1];
    newton_raphson(l1,l2);
    return 0;
}
double obj_fun_1(double x)
{

    // Maximize f(x) = (2x-5)^4 - (x^2 - 1)^3
    // return pow(pow(x,2.0)-1,3.0)-pow((2*x-5),4.0);

    // Maximize f(x) = 8 + x^3 - 2*x - 2e^x
    // return 2*x + 2*(pow(2.718,x))- pow(x,3.0)- 8;

    // Maximize f(x) = 4x(sin(x))
    // return -4*x*sin(x);

    // Minimize f(x) = 2(x-3)^2 + e^(0.5x^2)
     return 2*(pow(x-3,2.0)) + pow(2.718,0.5*(pow(x,2.0)));

    // Minimize f(x) = x^2 - 10e^(0.1x)
    // return (x*x) - 10*(pow(2.718,0.1*x));

    // Maximize f(x) = 20sin(x) - 15x^2
    // return (15*x*x) - 20*sin(x);
}

double bounding_phase(double a, double b, double limits[])
{
    double x,x1,x2,x3,f1,f2,f3;
    FILE *out_bp;
    printf("\n---------------------------\n");
    printf("Bounding Phase Method\n");
    //Step 1
    printf("Enter initial guess between a and b\n");
    scanf("%lf", &x);
    double delta;
    printf("Enter increment delta");
    scanf("%lf", &delta);
    int feval;// Function Evaluations
    int k=0;// No. of Iterations
    //Step 2
    while(1)
    {   feval=0;
        x1=x-delta; //New Points
        x2=x;
        x3=x+delta;
        f1=obj_fun_1(x1); // Calculate Objective Function
        f2=obj_fun_1(x2);
        f3=obj_fun_1(x3);
        feval=feval+3;
        if(f1>=f2 && f2>=f3) // Check whether delta should be taken +ve or -ve
        {
            printf("Delta is positive");
            break;
        }
        else if(f1<=f2 && f2<=f3)
        {
            printf("Delta is negative");
            delta=delta*(-1);
            break;
        }
        else
        {
            printf("Choose a different set of x and delta.\n Enter new value of x");
            scanf("%lf",&x);
            printf("Enter new value of delta");
            scanf("%lf",&delta);
        }
    }
    out_bp= fopen("Bounding_Phase_Iterations.out","w"); //Output File
    fprintf(out_bp,"#It\t x\t F(x)\n");
    fprintf(out_bp,"%d\t %lf\t %lf\n", k,x,f2);
    //Step 3
    double fold,fnew,xprev;
    do
    {   if(k==0)
        {
            fold=f2; // Storing previous iteration values to print range
            xprev=x;
        }
        else
        {
            fold=fnew;
            xprev=x-((pow(2.0,k-1))*delta);
        }
        x=x+(pow(2.0,k)*delta); // Update Value of x
        k=k+1;
        //STEP 4

        if(xprev < a)
        {
            xprev=a;
        }
        if(x < a)
        {
            x=a;
        }
        if(xprev > b)
        {
            xprev=b;
        }
        if(x > b)
        {
            x=b;
        }
        fnew=obj_fun_1(x);
        feval++;
        fprintf(out_bp,"%d\t %lf\t %lf\n", k,x,fnew);
    }while(fnew<fold);//Termination Condition
    printf("\n---------------------------\n");
    printf("The minimum lies in (%lf , %lf)", xprev,x);
    printf("\n#Total number of function evaluations: %d",feval);
    // Store in the file
    fprintf(out_bp,"The minimum lies in (%lf , %lf)", xprev,x);
    fprintf(out_bp,"\n#Total number of function evaluations: %d",feval);
    fclose(out_bp);
    limits[0]=xprev;
    limits[1]=x;
    return 1;
}

double newton_raphson(double xprev, double x)
{   double y,error,chk,del,y11,y12,f10,f11,f12,first_der,sec_der;
    FILE *out_nr;
    printf("\n---------------------------\n");
    printf("Newton Raphson Method\n");
    //Step 1
    printf("Choose initial guess between %lf and %lf",xprev,x);
    scanf("%lf", &y);
    printf("Choose truncation error value");
    scanf("%lf", &error);
    int k=1; // Number of iterations
    int feval=0; // Function Evaluations
    del=0.0000001; // Delta value for central difference
    out_nr= fopen("Newton_Raphson_Iterations.out","w"); // Output file
    fprintf(out_nr,"#It\t x\t F\'(x)\t F\"(x)\n");
    do
    {
        y11=y+del; //Points for calculating central difference
        y12=y-del;
        f10=obj_fun_1(y); // Function Values at new points
        f11=obj_fun_1(y11);
        f12=obj_fun_1(y12);
        first_der=(f11-f12)/(2*del); // Calculate First Derivative
        //Step 2
        sec_der=(f11+f12-(2*f10))/pow(del,2.0); // Calculate Second Derivative
        //Step 3
        y=y-(first_der/sec_der); // Update value of y
        //Step 4
        if(first_der<0)  // Modulus of first derivative to check termination condition
        {
            chk=first_der*(-1);
        }
        else
        {
            chk=first_der;
        }
        fprintf(out_nr,"%d\t %lf\t %lf\t %lf\n", k,y,first_der, sec_der);
        k=k+1;
        feval=feval+5;
    }while(chk>error);//Termination Condition
    printf("\n---------------------------\n");
    printf("After %d iterations f\'x = %lf < %lf\n", k,first_der,error);
    printf("The optimum value of x = %lf\n",y);
    printf("\n#Total number of function evaluations: %d",feval);
    // Store in the file
    fprintf(out_nr,"The optimum value of x = %lf\n", y);
    fprintf(out_nr,"\n#Total number of function evaluations: %d",feval);
    fclose(out_nr);
    return y;
}
